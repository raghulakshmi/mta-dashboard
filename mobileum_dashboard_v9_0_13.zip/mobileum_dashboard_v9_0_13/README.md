# Mobileum MTA Dashboard v9.0.13

This release makes Exim delivery deferrals operationally unambiguous.

## Delivery outcome model

The SMTP / Exim Delivery view now separates each downstream leg into:

- **Delivered** — successful `=>` delivery events for that router.
- **Temporary Defer** — recipient-level `==` defer events excluding Exim retry-backoff suppression.
- **Retry Backoff** — `==` events containing `retry time not reached`; these are retry-suppression events, not unique queued messages.
- **Permanent Failed** — permanent `**` delivery failures.

The Delivery view also shows **Current Queue**, obtained from live `exim4 -bpc`. This is the value to use when determining how many messages are actually pending at that moment.

The Overview's rolling 60-second Delivery Legs table uses the same split. The general top-level counter is renamed **Defer Events / min** to make clear that it is an event counter rather than queue depth.

## Why this change was made

During production observation, Proofpoint returned temporary `421 ... closing connection` responses. Exim then entered normal retry backoff and emitted many `defer (-54): retry time not reached for any host` records. The older dashboard grouped all of those records under **Deferred**, which could make hundreds of retry/backoff events look like hundreds of currently queued messages.

v9.0.13 separates those meanings while retaining the original raw counters in the database for compatibility.

## Exim configuration-query safety

Dashboard telemetry, runtime checks, queue display, and mail-search diagnostics now query the **system/default Exim configuration only** and do not invoke Exim with `-C`. This avoids the commissioning-time `exim user lost privilege for using -C option` paniclog condition.

## Upgrade

From the extracted package on the Jumpbox:

```bash
sudo ./bin/install-jumpbox.sh
```

The installer preserves the existing SQLite history and creates a timestamped backup of the previous application code before upgrading.


## v9.0.13 Failure drill-down
Delivery failure/defer counters are clickable. Failure Details groups exact Exim reasons (for example `550 5.4.1 Recipient address rejected: Access denied`), shows event/unique-message/unique-recipient counts, lists matching messages, and provides Trace and Raw actions.
