# Mobileum MTA Dashboard v9.0.13

- Clickable Proofpoint/Barracuda Temporary Defer, Retry Backoff, and Permanent Failed counters.
- Failure Details view with reason summary, top recipients, message-level rows, raw Exim evidence, and one-click Message Trace.
- Top-level Proofpoint Permanent Failed and Barracuda Permanent Failed cards on Delivery.
- Preserves v9.0.12 defer/backoff split and live queue depth.


## Deferred-event clarity

- Splits per-leg **Deferred** into **Temporary Defer** and **Retry Backoff**.
- `retry time not reached` records are counted only as Retry Backoff.
- Adds **Current Queue** to the Delivery view so historical retry events are not confused with live pending messages.
- Renames the Overview KPI to **Defer Events / min**.
- Retains legacy aggregate deferred counters in SQLite for backward compatibility.

## Exim command safety

- Removes dashboard/collector use of Exim `-C` configuration overrides.
- Runtime, queue and mail-search telemetry now use the system/default Exim configuration.

## Carried forward

- v9.0.11 aggregate delivery-event counter.
- v9.0.10 selected-window Proofpoint/Barracuda totals.
- v9.0.9 persistent MTA selection and Run Now.
- v9.0.8 per-leg delivery outcome counters.
- v9.0.7 CPU / RAM / Load / Network header metrics.
- v9.0.6 SQLite connection/file-descriptor leak fix and Sender + Recipient Mail Search correlation.

---

# Mobileum MTA Dashboard v9.0.11

## Total Delivery Events counter

- Adds **Total Delivery Events** to the Overview immediately below **Delivery Legs — last minute**.
- The large value follows the dashboard Window selector (1h / 4h / 12h / 24h / 48h / 7d).
- The same card also shows **Till date**, calculated across all Exim mainlog files currently retained on the selected MTA.
- Total Delivery Events is the sum of successful Proofpoint and Barracuda delivery-leg events.
- Therefore one message successfully delivered to both downstream systems counts as **two delivery events**.
- Proofpoint Delivered and Barracuda Delivered remain independent counters.

## Carried forward

- v9.0.10 selected-window Proofpoint/Barracuda totals.
- v9.0.9 persistent MTA selection and Run Now.
- v9.0.8 per-leg Delivered / Deferred / Failed counters.
- v9.0.7 CPU / RAM / Load / Network header metrics.
- v9.0.6 SQLite connection/file-descriptor leak fix and Sender + Recipient Mail Search correlation.
