# Mobileum MTA Dashboard v9.0.16

- Finalizes the detailed local **Message Analysis** view introduced in v9.0.15.
- Presents Message ID, MTA, sender, recipients, delivery path, Proofpoint evidence, Barracuda evidence, root cause, failure domain, TLS observations, Exim-fault assessment, and recommended action.
- Detects `550 5.4.1 Recipient address rejected: Access denied` as matching Microsoft 365 Exchange Online Directory-Based Edge Blocking (DBEB) behavior.
- When Barracuda is the observed SMTP peer, explicitly reports **Definitive rejecting system: NOT DETERMINABLE FROM EXIM LOG ALONE** rather than incorrectly blaming Barracuda or Microsoft 365.
- Recommends validating the recipient in Barracuda directory/recipient validation and Microsoft 365/Exchange Online, and checking Barracuda Message Log before replay.
- Gives an explicit SMTP 4xx/5xx response precedence over a later TLS-close warning when the SMTP transaction reached that response.
- Does not classify `CV=no` by itself as TLS failure.
- Analyzer retrieves events for the exact selected Exim Message-ID, avoiding adjacent-message contamination from context grep output.
- Runs locally on the Jumpbox with no ChatGPT/OpenAI/API dependency.
- Retains v9.0.15 and earlier functionality.

# Mobileum MTA Dashboard v9.0.15

- Adds automatic local **Message Analysis** to Mail Search / Message Trace; selecting Trace automatically analyzes the same retained Exim Message-ID.
- Correlates inbound acceptance, safety archive, Proofpoint, Barracuda, TLS, SMTP responses, failure stage, error-ignored behavior, and Exim completion.
- Adds evidence-based Root Cause, Failure Domain, Exim-fault assessment, and Recommended Action sections.
- Recognizes `550 5.4.1 Recipient address rejected: Access denied` as matching Microsoft 365 Exchange Online DBEB behavior while explicitly stating that the Exim trace alone cannot prove whether Barracuda or Microsoft 365/EOP was the definitive rejecting system.
- Treats explicit SMTP responses as authoritative over a later TLS-close warning when the transaction progressed far enough to return the SMTP response.
- Does not treat `CV=no` alone as a TLS failure.
- Analysis is deterministic and runs locally on the Jumpbox; no OpenAI/ChatGPT/API dependency.
- Retains all v9.0.14 functionality.

# Mobileum MTA Dashboard v9.0.14

- Adds a dedicated **Help** tab under SMTP / Exim with plain-English explanations of dashboard numbers, SMTP 2xx/4xx/5xx families, 421/450/451/452, 501/550 examples, Retry Waiting, Completed, error ignored, TLS shutdown warnings, and event-vs-message counting.
- Renames **Temporary Defer** to **Temporary Failure** and **Retry Backoff** to **Retry Waiting** in the UI.
- Enhances Failure Details with an evidence-derived classification, plain-English meaning, and recommended action for each reason and each message-level event.
- Adds production-aware guidance for 550 5.4.1 Access denied, 501 5.1.7/5.1.8 SMTPUTF8 recipient failures, 421/450/451/452 temporary failures, retry waiting, and historical long-line transport failures.
- Keeps Trace and Raw evidence actions and all v9.0.13 delivery drill-down capabilities.
- Uses system/default Exim configuration only; no `-C` telemetry calls.
