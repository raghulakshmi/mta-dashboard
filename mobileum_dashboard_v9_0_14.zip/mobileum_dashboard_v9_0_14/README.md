# Mobileum MTA Dashboard v9.0.14

This release focuses on operational clarity for customer-facing mail-flow investigation.

## Delivery terminology

- **Delivered** — successful downstream delivery event.
- **Temporary Failure** — recipient delivery was deferred and remains retryable.
- **Retry Waiting** — Exim is waiting until the next retry time after an earlier temporary failure; this is not current queue depth.
- **Permanent Failed** — downstream route permanently rejected the recipient delivery.
- **Current Queue** — live Exim queue depth and the correct value for “how many messages are waiting now?”.

## Failure Details

Click Proofpoint/Barracuda Temporary Failure, Retry Waiting, or Permanent Failed counts to open Failure Details. The view now provides:

- event count, unique messages and unique recipients;
- top classification and exact reason;
- plain-English meaning;
- recommended action;
- grouped reason summary and top recipients;
- message-level rows with Trace and Raw evidence.

The dashboard does not infer mailbox validity from an address name. For downstream 550 recipient rejections, it directs the operator to validate recipient state, Barracuda directory/recipient validation and Microsoft 365 recipient/connector handling before replay.

## Help tab

The SMTP / Exim Help tab explains the dashboard without requiring the operator to memorize SMTP codes. It includes:

- Accepted, Completed, Current Queue, Delivered, Temporary Failure, Retry Waiting and Permanent Failed;
- 2xx success, 4xx temporary and 5xx permanent response families;
- 421, 450, 451 and 452 temporary responses;
- 550 5.4.1 Access denied and 501 SMTPUTF8/address-syntax examples;
- Exim `retry time not reached`, `Completed`, `error ignored`, TLS shutdown warnings and recipient-level event counting;
- a safe investigation sequence.

## Upgrade

From the extracted package on the Jumpbox:

```bash
sudo ./bin/install-jumpbox.sh
```

The installer preserves the existing SQLite monitoring history and creates a timestamped backup of the previous application code before upgrading.
