# Mobileum MTA Dashboard v9.0.14

- Adds a dedicated **Help** tab under SMTP / Exim with plain-English explanations of dashboard numbers, SMTP 2xx/4xx/5xx families, 421/450/451/452, 501/550 examples, Retry Waiting, Completed, error ignored, TLS shutdown warnings, and event-vs-message counting.
- Renames **Temporary Defer** to **Temporary Failure** and **Retry Backoff** to **Retry Waiting** in the UI.
- Enhances Failure Details with an evidence-derived classification, plain-English meaning, and recommended action for each reason and each message-level event.
- Adds production-aware guidance for 550 5.4.1 Access denied, 501 5.1.7/5.1.8 SMTPUTF8 recipient failures, 421/450/451/452 temporary failures, retry waiting, and historical long-line transport failures.
- Keeps Trace and Raw evidence actions and all v9.0.13 delivery drill-down capabilities.
- Uses system/default Exim configuration only; no `-C` telemetry calls.
